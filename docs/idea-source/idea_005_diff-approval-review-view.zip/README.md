# 比較・差分承認ビュー 開発パック

| 項目 | 内容 |
| --- | --- |
| 領域 | ProjectManagement |
| No. | 5 |
| 分野 | レビュー・承認 |
| アイデア | 比較・差分承認ビュー |
| リポジトリ名 | diff-approval-review-view |
| 概要 | 変更前後、候補同士、バージョン差分を比較して採用判断する。 入力、確認、履歴保存、次アクションを同じ作業単位で扱えるようにする。 |
| 課題 | 変更理由や採用可否を複数画面で判断する必要がある。 |
| 類似サービス・アプリ | GitHub Projects, Linear, Jira, GitHub Actions, Codex, Claude Code, Cursor |
| 差別化ポイント | Issue、PR、設計ドキュメント、エージェント作業、リリース証跡を同じ流れで扱う。 差分、理由、採用操作を1つの承認フローにまとめる。 |

## 目的

このZIPには、`ProjectManagement` 領域のアイデア `比較・差分承認ビュー` を実装可能なプロジェクトへ落とし込むための初期ドキュメントが含まれています。

## 含まれるファイル

- START_PROMPT.md
- README.md
- 01_REQUIREMENTS.md
- 02_SPECIFICATION.md
- 03_DESIGN.md
- 04_IMPLEMENTATION_PLAN.md
- 05_TEST_PLAN.md
- 06_RELEASE_CHECKLIST.md
- metadata.json

## 使い方

1. Codexまたは他のコーディングエージェントへの最初のプロンプトとして `START_PROMPT.md` を使用する。
2. 実装前に要件、仕様、設計を確認する。
3. MVPを実装し、テスト計画に沿って検証する。
